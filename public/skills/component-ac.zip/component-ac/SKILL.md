---
name: component-ac
description: Write acceptance criteria for a Nest UI Kit component, ready to paste into a Jira ticket engineers can groom. Use when a designer asks for an AC document, a component spec, a hand-off doc, or a delta between a new Figma design and the shipped component. Reads the design from Figma and the current implementation from the nestoca/fe-shared repo.
---

# Component acceptance criteria

Produce a markdown document a front-end engineer can read during grooming and point without a second pass.

**The one rule: define the expected outcome. Leave the implementation to engineering.**

> "I don't think that the design team should be putting technical implementation details in the tickets. It's up to engineering to decide how a requirement will be handled." — front-end feedback, Aug 2026

You will be tempted to produce a file-by-file change list, a prop name and a deprecation strategy. It reads as thorough. It costs the engineer twice: your assumptions get baked into the ticket, so they must steer their own agent away from them, and they must work out which of your proposals are right before they can start. Assume you have over-specified, and cut back.

## 1. Intake

You need four things. Ask for whatever is missing — do not guess.

| Input | Notes |
|---|---|
| **Figma link** | Must contain `node-id=`. A file-level link is the wrong link; ask for a link to the specific frame or component set. |
| **Component name + status** | New, existing v1, or existing v2. If the designer is unsure, list what exists (see §2) and confirm. |
| **Accessibility spec** | A Confluence page, or `none`. |
| **Decisions already made** | Rulings from a review, Slack, or a call. **This is the one that matters.** |

**Never invent a decision.** Rules like "row click is decided per table, not per row" cannot be derived from a design file. If a behaviour is ambiguous and no ruling covers it, it goes in **Open decisions** — not into a criterion phrased as though it were settled.

## 2. Sources

**Design — Figma.** Use whichever Figma access this environment has: the Figma MCP server or a Figma connector. In Claude Code, load the `figma-use` skill before any `use_figma` call.

**Current implementation — the `nestoca/fe-shared` repo.** Needed only for an update; a new component has nothing to compare against.

- v1 components: `packages/ui/src/components/`
- v2 components: `packages/ui/src/v2/components/`
- **Never Storybook.** It is a single-page app and returns an empty shell when fetched. Reading source is better anyway — it surfaces deprecated tokens and real prop shapes the docs page hides.

Reach it however this environment allows:

| Environment | How |
|---|---|
| Claude Code | The `gh` CLI. List components with `gh api repos/nestoca/fe-shared/contents/packages/ui/src/components --jq '.[].name'` |
| Claude Desktop / web | A GitHub connector, if one is configured for this repo |

**If you cannot reach the repo**, say so plainly before you start. Then offer the designer two choices: paste the component's source and stories, or proceed from the design alone. If they proceed design-only, drop *Already correct — do not rebuild* and the code-read appendix, and add a line to **Open decisions** saying the current implementation was not read — so nobody mistakes silence for verification.

## 3. How to write it

Use **Simplified Technical English** (ASD-STE100 — a controlled-English standard from aerospace manuals, built so a reader under time pressure cannot misread an instruction).

- Plain, common words. If a technical term is unavoidable, explain it in the same breath.
- Active voice. "The row expands", not "the row is expanded".
- One idea per criterion. If a criterion contains "and", it is usually two criteria.
- Short sentences, short paragraphs. A criterion that needs a paragraph is one you have not finished thinking about.
- Only what is necessary. No preamble, no summary of what follows, no restating the design.

### Three tests before a line stays in

1. **Can I check it from outside the component?** If the sentence names a file, prop, hook, CSS property or function, it is implementation. Rewrite it as behaviour a person can observe.
2. **Could an engineer satisfy this in a way I did not imagine?** If not, you specified the *how*. Widen it until they could.
3. **Would a reader know this anyway by the end of the document?** Then cut it.

### No measurements in the ticket

**Figma is the source for values. The ticket is the source for behaviour.** The developer reads exact sizes, spacing and colours from the design file, never from the Jira description. A number in the ticket is duplication at best, and a second source of truth that goes stale at worst.

Write the rule, not the number:

| Instead of | Write |
|---|---|
| A row is at least 48px tall and grows to fit its content. | A row has a minimum height and grows to fit its content. |
| Utility columns are 32px wide. | Utility columns are a fixed narrow width, the same in every table. |
| The default size moves from 24px to 32px. | The default size moves up one step on the scale. |
| Full-width 32px band, `#EFEFF6`, 12px SemiBold label. | A full-width band, visually quieter than a data row, with a label heavier than the rows below it. |

When a rule genuinely hinges on a specific value — two things must match, or a threshold must be named — **name the token, never the number**: `semantic-sizing/12`, `color/background/muted`, `component/small (12)/semibold`. A token name is a reference the developer can look up; a number is a copy that drifts.

Never write a raw unit. Not `48px`, not `3rem`, not `0.5rem 0.625rem`. A unit is doubly wrong: a value *and* a code decision that is not design's to make.

**Reading tokens.** They are **remote**, so listing the file's local variables returns nothing and looks like "this component has no tokens". Read the variable bound to the layer (`node.boundVariables`) and resolve its `VARIABLE_ALIAS` chain. The scale index is not the pixel value — `semantic-sizing/12` is 48px because the ramp is 4×N, so matching a token to the inspector's number is wrong by a factor of four. If a component has no bindings at all, that is a finding for the design-system owner and belongs in **Open decisions**.

**One exception:** thresholds from outside the design system — a WCAG target of 24×24, a contrast ratio of ≥3:1. These are not in Figma and are not design decisions. State them, and say where they come from.

### The anatomy trap

The most common way an AC goes wrong is not a bad sentence, it is a bad **spine**. A document organised around what the component is *made of* — top-level blocks, then groups, then atoms — describes the component completely and still misses most of what it *does*. Composition tables have no home for "clicking the row expands it" or "pinned rows survive a search".

Organise by **behaviour**. Add structure only where structure is the requirement. Cardinality usually is — *exactly one header row*, *zero or one footer* are observable facts. *Built from Icon + Label + optional trailing slot* is the Figma tree, and is not.

### Open decisions

A question with no shape is work for the reader. Give **at most two options**, the context needed to choose quickly, and say which one you would take.

| Instead of | Write |
|---|---|
| What should happen to the `outline` style? | Withdraw `outline`, or design it. Nothing in the new component uses it and no screen depends on it — **recommend withdrawing**. |

Recommend where you have grounds. Where the choice turns on something outside design — release strategy, consumer breakage — say **"no design preference"** and hand it over. An invented recommendation on a decision you have no standing to make is worse than none.

## 4. Structure

Same shape for a new component or an update. On an **update**, the first table is a **gap** table (Add / Change / Remove) and you keep three sections: *Already correct — do not rebuild*, *Appendix — notes from a code read*, and a **migration impact** row in Open decisions. On a **new component**, the first table is a **scope** table and those three sections are deleted.

Migration impact is the thing reviewers miss most: a changed default silently alters every instance that never set the prop.

```markdown
# <Component> — acceptance criteria

**Design:** <Figma link>
**Accessibility:** <link, if a separate spec owns it>. Where a rule appears in both, that page wins.

| # | Gap | |
|---|---|---|
| 1 | <what's missing today, in the user's terms> | Add / Change / Remove |

## 0. Already correct — do not rebuild
<Updates only. What the current implementation already does properly, so nobody
rebuilds it. Two lines, not an inventory.>

---

## 1. <Group of related criteria — named for a behaviour, not a part>

- **1.1** <One observable outcome per line. No sizes, no colours.>
- **1.2** <Testable without opening the code.>

## N. Usage rules
<Design guidance that isn't a code change but belongs in the stories.>

---

## N+1. Out of scope
<Visible in the design file, not covered by this ticket, so it can't be assumed
forgotten. Say where it lives instead and that it's frozen.>

## N+2. Owned elsewhere
<Areas another spec covers, titles only. Never restate a rule that lives in two
documents — they drift, and nobody knows which one won.>

## N+3. Open decisions
| Question | Owner |
|---|---|
| <Two options max, the context to choose, and the one you'd take.> | Engineering / Design / Product / A11y |

**Settled, do not reopen:** <one line, so revisions don't re-litigate>

---

## N+4. Appendix — notes from a code read
**Not requirements**, and not a proposed approach. Discard freely.
<Anything technical you learned that saves them a first look.>
```

Technical detail is not binned — it goes at the bottom, or in a Jira comment, labelled *not requirements*.

## 5. Before handing it over

- [ ] Read only the section headings. If they name parts rather than behaviours, the spine is wrong — fix that before the sentences.
- [ ] No file paths, prop names or CSS properties in the main body.
- [ ] Search for a digit followed by `px`, `rem`, `em` or `ms`. There should be no hits, except an external threshold that says where it came from.
- [ ] Any token name was read from the bound variable, not from memory. Any unbound value is raised in Open decisions.
- [ ] Every criterion is one sentence, active voice, one idea, observable from outside the component.
- [ ] Every open decision gives two options max, and either names the one you'd take or says "no design preference".
- [ ] Nothing stated in two places, including across two documents.
- [ ] Rationale is one clause, not a paragraph, and only where the rule is surprising.
- [ ] Out of scope checked against the Figma frame for anything visible but excluded.
- [ ] Every section that does not apply is deleted. A template filled in for its own sake is fluff by another name.

## 6. Reporting back

Keep the chat reply as short as the document: what you did, whether it worked, what the designer does next. Point them at the **Open decisions** table — it is the only part they need to read. Exact paths and links, nothing else.

---

*Longer rationale, worked examples and the designer-facing instructions: [Writing AC documents engineers can groom](https://nestoca.atlassian.net/wiki/x/d4G9OgE).*
