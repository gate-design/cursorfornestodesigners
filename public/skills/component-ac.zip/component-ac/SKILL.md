---
name: component-ac
description: Write acceptance criteria for a Nest UI Kit component and file them into the Jira ticket. Use when a designer asks for an AC document, a component spec, a hand-off doc, or a delta between a new Figma design and the shipped component. Reads the design from Figma and the current implementation from the nestoca/fe-shared repo, then writes the result into the ticket rather than handing back a file to paste.
---

# Component acceptance criteria

Produce a markdown document a front-end engineer can read during grooming and point without a second pass.

**The one rule: define the expected outcome. Leave the implementation to engineering.**

> "I don't think that the design team should be putting technical implementation details in the tickets. It's up to engineering to decide how a requirement will be handled." — front-end feedback, Aug 2026

You will be tempted to produce a file-by-file change list, a prop name and a deprecation strategy. It reads as thorough. It costs the engineer twice: your assumptions get baked into the ticket, so they must steer their own agent away from them, and they must work out which of your proposals are right before they can start. Assume you have over-specified, and cut back.

## 1. Intake

You need five things. Ask for whatever is missing — do not guess.

| Input | Notes |
|---|---|
| **Figma link** | Must contain `node-id=`. A file-level link is the wrong link; ask for a link to the specific frame or component set. |
| **Component name** | And whether it is **new** or an **update** to something that already ships. Work out where the code lives yourself (§2). Never ask the designer which generation of the library it sits in — that is a codebase detail, not theirs to know. |
| **Accessibility spec** | A Confluence page, or `none`. |
| **Decisions already made** | Rulings from a review, Slack, or a call. **This is the one that matters.** |
| **Jira ticket** | The ticket the AC belongs in, or `none`. You write the document into the ticket yourself — see §5. Never make the designer copy and paste it. |

**Never invent a decision.** Rules like "row click is decided per table, not per row" cannot be derived from a design file. If a behaviour is ambiguous and no ruling covers it, it goes in **Open decisions** — not into a criterion phrased as though it were settled.

## 2. Sources

**Design — Figma.** Use whichever Figma access this environment has: the Figma MCP server or a Figma connector. In Claude Code, load the `figma-use` skill before any `use_figma` call.

**Current implementation — the `nestoca/fe-shared` repo.** Needed only for an update; a new component has nothing to compare against.

**Look in `packages/ui/src/v2/components/` first.** v2 is the current generation and is what a design update targets.

`packages/ui/src/components/` is v1 and is **largely deprecated**. Treat it as prior art, not the target:

- **In both** (accordion, banner, form, table, tooltip) — write the AC against **v2**. Mention v1 only where it is genuinely useful, such as a capability the v2 rewrite dropped. Do not ask the designer which one they mean.
- **In v1 only** — say so plainly. The design may be part of moving that component to v2, which is worth a line in the AC and possibly a row in Open decisions.

**Never Storybook.** It is a single-page app and returns an empty shell when fetched. Reading source is better anyway — it surfaces deprecated tokens and real prop shapes the docs page hides.

Reach it however this environment allows:

| Environment | How |
|---|---|
| Claude Code | The `gh` CLI. List v2 components with `gh api repos/nestoca/fe-shared/contents/packages/ui/src/v2/components --jq '.[].name'` |
| Claude Desktop / web | A GitHub connector, if one is configured for this repo |

**If you cannot reach the repo**, say so plainly before you start. Then offer the designer two choices: paste the component's source and stories, or proceed from the design alone. If they proceed design-only, drop *Already correct — do not rebuild* and the code-read appendix, and add a line to **Open decisions** saying the current implementation was not read — so nobody mistakes silence for verification.

## 3. How to write it

Use **Simplified Technical English** (ASD-STE100 — a controlled-English standard from aerospace manuals, built so a reader under time pressure cannot misread an instruction).

- Plain, common words. If a technical term is unavoidable, explain it in the same breath.
- Active voice. "The row expands", not "the row is expanded".
- One idea per criterion. If a criterion contains "and", it is usually two criteria.
- Short sentences, short paragraphs. A criterion that needs a paragraph is one you have not finished thinking about.
- Only what is necessary. No preamble, no summary of what follows, no restating the design.

### Three tests before a line stays in

1. **Can I check it from outside the component?** If the sentence names a file, prop, hook, CSS property or function, it is implementation. Rewrite it as behaviour a person can observe.
2. **Could an engineer satisfy this in a way I did not imagine?** If not, you specified the *how*. Widen it until they could.
3. **Would a reader know this anyway by the end of the document?** Then cut it.

### No measurements in the ticket

**Figma is the source for values. The ticket is the source for behaviour.** The developer reads exact sizes, spacing and colours from the design file, never from the Jira description. A number in the ticket is duplication at best, and a second source of truth that goes stale at worst.

Write the rule, not the number:

| Instead of | Write |
|---|---|
| A row is at least 48px tall and grows to fit its content. | A row has a minimum height and grows to fit its content. |
| Utility columns are 32px wide. | Utility columns are a fixed narrow width, the same in every table. |
| The default size moves from 24px to 32px. | The default size moves up one step on the scale. |
| Full-width 32px band, `#EFEFF6`, 12px SemiBold label. | A full-width band, visually quieter than a data row, with a label heavier than the rows below it. |

When a rule genuinely hinges on a specific value — two things must match, or a threshold must be named — **name the token, never the number**: `semantic-sizing/12`, `color/background/muted`, `component/small (12)/semibold`. A token name is a reference the developer can look up; a number is a copy that drifts.

Never write a raw unit. Not `48px`, not `3rem`, not `0.5rem 0.625rem`. A unit is doubly wrong: a value *and* a code decision that is not design's to make.

**Reading tokens.** They are **remote**, so listing the file's local variables returns nothing and looks like "this component has no tokens". Read the variable bound to the layer (`node.boundVariables`) and resolve its `VARIABLE_ALIAS` chain. The scale index is not the pixel value — `semantic-sizing/12` is 48px because the ramp is 4×N, so matching a token to the inspector's number is wrong by a factor of four. If a component has no bindings at all, that is a finding for the design-system owner and belongs in **Open decisions**.

**One exception:** thresholds from outside the design system — a WCAG target of 24×24, a contrast ratio of ≥3:1. These are not in Figma and are not design decisions. State them, and say where they come from.

### The anatomy trap

The most common way an AC goes wrong is not a bad sentence, it is a bad **spine**. A document organised around what the component is *made of* — top-level blocks, then groups, then atoms — describes the component completely and still misses most of what it *does*. Composition tables have no home for "clicking the row expands it" or "pinned rows survive a search".

Organise by **behaviour**. Add structure only where structure is the requirement. Cardinality usually is — *exactly one header row*, *zero or one footer* are observable facts. *Built from Icon + Label + optional trailing slot* is the Figma tree, and is not.

### Open decisions

A question with no shape is work for the reader. Give **at most two options**, the context needed to choose quickly, and say which one you would take.

| Instead of | Write |
|---|---|
| What should happen to the `outline` style? | Withdraw `outline`, or design it. Nothing in the new component uses it and no screen depends on it — **recommend withdrawing**. |

Recommend where you have grounds. Where the choice turns on something outside design — release strategy, consumer breakage — say **"no design preference"** and hand it over. An invented recommendation on a decision you have no standing to make is worse than none.

## 4. Structure

Same shape for a new component or an update. On an **update**, the first table is a **gap** table (Add / Change / Remove) and you keep three sections: *Already working — leave alone*, *Appendix — notes from a code read*, and a **migration impact** row in Open decisions. On a **new component**, the first table is a **scope** table and those three sections are deleted.

**Numbered sections are criteria. Nothing else takes a number in that run.** *Already working*, *Out of scope*, *Owned elsewhere* and *Open decisions* are context and sit after the criteria. A context section dressed as section 0 reads like a criterion that forgot to be one — it was the first thing a reviewer flagged.

**Every section reads the same way**: short bullets, one idea each. *Already working* is the one that drifts into prose, and it is also the one a reader is least equipped to follow, since it describes a component they may never have seen. Name one thing per bullet.

Migration impact is the thing reviewers miss most: a changed default silently alters every instance that never set the prop.

```markdown
# <Component> — acceptance criteria

**Design:** <Figma link>
**Accessibility:** <link, if a separate spec owns it>. Where a rule appears in both, that page wins.

| # | Gap | |
|---|---|---|
| 1 | <what's missing today, in the user's terms> | Add / Change / Remove |

## 0. Already correct — do not rebuild
<Updates only. What the current implementation already does properly, so nobody
rebuilds it. Two lines, not an inventory.>

---

## 1. <Group of related criteria — named for a behaviour, not a part>

- **1.1** <One observable outcome per line. No sizes, no colours.>
- **1.2** <Testable without opening the code.>

## N. Usage rules
<Design guidance that isn't a code change but belongs in the stories.>

---

## N+1. Already working — leave alone
<Updates only. Bullets, not a paragraph — one named thing per line, in the same
voice as the criteria above. Open with a line like "These already ship and
already match the design." A reader who has never seen the current component
must still be able to follow it.>

## N+2. Out of scope
<Visible in the design file, not covered by this ticket, so it can't be assumed
forgotten. Say where it lives instead and that it's frozen. Different from
"already working": that ships and is correct, this is not being built.>

## N+3. Owned elsewhere
<Areas another spec covers, titles only. Never restate a rule that lives in two
documents — they drift, and nobody knows which one won.>

## N+4. Open decisions
| Question | Owner |
|---|---|
| <Two options max, the context to choose, and the one you'd take.> | Engineering / Design / Product / A11y |

**Settled, do not reopen:** <one line, so revisions don't re-litigate>

---

## N+5. Appendix — notes from a code read
**Not requirements**, and not a proposed approach. Discard freely.
<Anything technical you learned that saves them a first look.>
```

Technical detail is not binned — it goes at the bottom, or in a Jira comment, labelled *not requirements*.

## 5. Delivery — write it into the ticket

**The designer should never copy and paste the document.** If they gave you a Jira ticket, put the AC in it yourself.

Use whatever Atlassian access this environment has — the Atlassian MCP tools in Claude Code, or the Atlassian connector in Desktop.

**Write the description as ADF, not markdown.** Markdown cannot carry a panel or a column width, and both matter:

**A warning panel at the very top, whenever Open decisions has any rows.** The designer reads the ticket first, so tell them what is still unsettled before they scroll. Say how many, where they are, and that they belong in kickoff:

```json
{"type":"panel","attrs":{"panelType":"warning"},"content":[{"type":"paragraph","content":[
  {"type":"text","text":"6 open decisions still need answers","marks":[{"type":"strong"}]},
  {"type":"text","text":" — see section 9. Settle them before or during kickoff with engineering. Do not point this ticket until they are done."}]}]}
```

Put a second, shorter panel directly above the Open decisions table itself. No open decisions means no panels at all — never a reassuring banner saying everything is settled.

**Column widths on both tables.** Left to itself Jira gives every column equal width, which wastes the gap table on a two-character number. Set `colwidth` on every cell, header and body alike:

| Table | Widths |
|---|---|
| Gap | `#` 52, gap text 700, Add/Change/Remove 110 |
| Open decisions | question 720, owner 142 |


**Read the ticket before you write to it.**

- **Description empty** — write the AC into it. Report back with the ticket link.
- **Description already has content** — do not overwrite it silently. Show what is there in a sentence, then ask: replace it, add the AC below it, or post the AC as a comment instead. Wait for the answer.
- **Appendix** — post *Appendix — notes from a code read* as a **comment**, not in the description. It is not a requirement, and the description should stay groomable.

**Touch the description only.** Do not change the summary, status, assignee, labels, components, or any other field unless the designer asks. It is their ticket.

**If there is no ticket, or you cannot reach Jira**, save the markdown to a file, say exactly where, and tell them it is ready to paste. Do not treat this as a failure — it is the fallback, not an error.

## 6. Before handing it over

- [ ] Read only the section headings. If they name parts rather than behaviours, the spine is wrong — fix that before the sentences.
- [ ] No file paths, prop names or CSS properties in the main body.
- [ ] Search for a digit followed by `px`, `rem`, `em` or `ms`. There should be no hits, except an external threshold that says where it came from.
- [ ] Any token name was read from the bound variable, not from memory. Any unbound value is raised in Open decisions.
- [ ] Every criterion is one sentence, active voice, one idea, observable from outside the component.
- [ ] Every open decision gives two options max, and either names the one you'd take or says "no design preference".
- [ ] Nothing stated in two places, including across two documents.
- [ ] Rationale is one clause, not a paragraph, and only where the rule is surprising.
- [ ] Out of scope checked against the Figma frame for anything visible but excluded.
- [ ] Every section that does not apply is deleted. A template filled in for its own sake is fluff by another name.
- [ ] For an update, the AC is written against the **v2** component. If only v1 exists, the document says so.
- [ ] The document is in the Jira ticket, not sitting in a file for the designer to paste. The appendix is a comment, not part of the description.
- [ ] Written as ADF. A warning panel sits at the top if Open decisions has rows, and both tables carry column widths.
- [ ] Only criteria take a number. Already working, Out of scope, Owned elsewhere and Open decisions come after them.

## 7. Reporting back

Keep the chat reply as short as the document: what you did, whether it worked, what the designer does next. Give them the **ticket link**, and point at the **Open decisions** table — it is the only part they need to read. Exact links, nothing else.

---

*Longer rationale, worked examples and the designer-facing instructions: [Writing AC documents engineers can groom](https://nestoca.atlassian.net/wiki/x/d4G9OgE).*
