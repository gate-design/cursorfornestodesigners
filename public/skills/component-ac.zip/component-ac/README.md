# component-ac

Writes acceptance criteria for a Nest UI Kit component, ready to paste into a Jira ticket.

Full rationale and worked examples: [Writing AC documents engineers can groom](https://nestoca.atlassian.net/wiki/x/d4G9OgE)

## Install

**Claude Desktop** — nothing to install; it's published to everyone at nesto.

> **Use Code mode.** Chat and Cowork will not run this skill — they lack the tools it needs to read Figma and the repo. Switch the mode picker to Code first. That's the first thing to check if `/component-ac` doesn't appear or doesn't do anything.

Then type `/component-ac`. If it still doesn't appear, check Settings → Capabilities → Skills that it's switched on.

**Claude Code** — unzip so the folder sits at:

```
~/.claude/skills/component-ac/
```

Restart your session, then type `/component-ac`.

Either way, you still need GitHub access for updates to existing components — see below.

## Use

```
/component-ac

Component: Chip — existing
Figma: https://www.figma.com/design/.../Nest-UI-Kit?node-id=420-1191
Accessibility spec: none
Decisions already made: none
```

You can also just type `/component-ac` and answer the questions it asks.

## What it needs

**The design** — a Figma MCP server (Claude Code) or the Figma connector (Desktop).

**The current implementation** — only for an existing component (an update). `nestoca/fe-shared` is private, so it needs your GitHub access:

*Claude Code*

```
brew install gh          # skip if `gh --version` works
gh auth login            # GitHub.com → HTTPS → log in with a browser
gh api repos/nestoca/fe-shared --jq .full_name   # should print nestoca/fe-shared
```

Accept the default scopes — you need `repo` for private repos and `read:org` for nesto's org.

*Claude Desktop*

Settings → Connectors → GitHub → connect. The `nestoca` org is already approved centrally, so there's nothing for you to grant.

### If it can't reach the repo

A **404** means no access, not a typo — GitHub hides private repos, so "not found" and "not permitted" look the same from outside. Two things to check:

- You can open github.com/nestoca/fe-shared in a browser while signed in. If not, your GitHub account isn't in the nesto org yet.
- `gh auth status` shows the account you expect — it's easy to be logged in as a personal account rather than the one with nesto access.

Beyond that, org access is managed centrally. Ask in Slack rather than trying to fix permissions yourself.

You can carry on regardless. The skill says up front that it couldn't read the code, then offers to work from the design alone — and records that in the document so nobody mistakes silence for verification.
