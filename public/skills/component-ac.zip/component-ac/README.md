# component-ac

Writes acceptance criteria for a Nest UI Kit component, ready to paste into a Jira ticket.

Full rationale and worked examples: [Writing AC documents engineers can groom](https://nestoca.atlassian.net/wiki/x/d4G9OgE)

## Install

**Claude Desktop** — nothing to do. It's published to everyone at nesto; just type `/component-ac`. If it doesn't appear, check Settings → Capabilities → Skills that it's switched on.

**Claude Code** — unzip so the folder sits at:

```
~/.claude/skills/component-ac/
```

Restart your session, then type `/component-ac`.

Either way, you still need GitHub access for updates to existing components — see below.

## Use

```
/component-ac

Component: Chip — existing
Figma: https://www.figma.com/design/.../Nest-UI-Kit?node-id=420-1191
Accessibility spec: none
Decisions already made: none
```

You can also just type `/component-ac` and answer the questions it asks.

## What it needs

**The design** — a Figma MCP server (Claude Code) or the Figma connector (Desktop).

**The current implementation** — only for an existing component (an update). `nestoca/fe-shared` is private, so it needs your GitHub access:

*Claude Code*

```
brew install gh          # skip if `gh --version` works
gh auth login            # GitHub.com → HTTPS → log in with a browser
gh api repos/nestoca/fe-shared --jq .full_name   # should print nestoca/fe-shared
```

Accept the default scopes — you need `repo` for private repos and `read:org` for nesto's org.

*Claude Desktop*

Settings → Connectors → GitHub → connect. On the GitHub authorisation screen, **grant the `nestoca` organisation**, not just your personal account. If it offers *Request* rather than *Grant*, an org owner has to approve it first. This is the step people miss.

### If it can't reach the repo

A **404** means no access, not a typo — GitHub hides private repos, so "not found" and "not permitted" look the same from outside. A **403** usually means the connector exists but wasn't granted the `nestoca` org. Check you can open github.com/nestoca/fe-shared in a browser; if you can't, it's an access request, not a setup problem.

You can carry on regardless. The skill says up front that it couldn't read the code, then offers to work from the design alone — and records that in the document so nobody mistakes silence for verification.
