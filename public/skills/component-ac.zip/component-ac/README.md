# component-ac

Writes acceptance criteria for a Nest UI Kit component, ready to paste into a Jira ticket.

Full rationale and worked examples: [Writing AC documents engineers can groom](https://nestoca.atlassian.net/wiki/x/d4G9OgE)

## Install

**Claude Code** — unzip so the folder sits at:

```
~/.claude/skills/component-ac/
```

Restart your session, then type `/component-ac`.

**Claude Desktop / web** — Settings → Capabilities → Skills → upload `component-ac.zip`.
(Available on paid plans. If you don't see Skills there, use Claude Code.)

## Use

```
/component-ac

Component: Chip — existing v1
Figma: https://www.figma.com/design/.../Nest-UI-Kit?node-id=420-1191
Accessibility spec: none
Decisions already made: none
```

You can also just type `/component-ac` and answer the questions it asks.

## What it needs

| For | Needs |
|---|---|
| The design | Figma MCP server or a Figma connector |
| The current implementation *(updates only)* | `gh` CLI in Claude Code, or a GitHub connector, with access to `nestoca/fe-shared` |

A **new** component needs only Figma. An **update** without repo access still works — it will tell you what it could not verify.
