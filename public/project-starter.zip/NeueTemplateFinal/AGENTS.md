# Agent Development Guidelines

## Overview

This document outlines the development standards and specifications for this project. All future development must follow these guidelines as defined in `cursor/skills/nesto-ui`.

## UI Component Library

### **DO NOT USE TAILWIND CSS**

Instead, use the following:

1. **React Components**: Use `fe-shared-master` for all React components
   - Import components from `fe-shared-master` package
   - Follow the component patterns and APIs defined in the fe-shared-master library
   - Use semantic elements where possible: `<Box />`, `<Flex />`, `<HStack />`, `<VStack />`, `<Stack />`, `<Grid />`

2. **Styling**: Use Nesto UI CSS variables
   - Import `@nestoca/ui/style` and `@nestoca/ui/variables` in your main entry file (e.g., `main.tsx`)
   - Use CSS custom properties (variables) defined in the UI package for colors, spacing, typography, etc.
   - Do not use Tailwind utility classes
   - Use CSS modules for component-specific styles
   - Apply styles using CSS modules with the same name as the component

## Technical Preferences

### Component Naming
- **Always use kebab-case for component file names** (e.g. `my-component.tsx`, `workspace-selector.tsx`)

### Styling Approach
- Use CSS modules when adding styles
- Do NOT use inline CSS or React style object attributes
- Apply styles using CSS modules with the same name as the component
- Prefer `clsx` when multiple styles are applied:
  ```tsx
  <Box classNames={clsx("one", "two", { baz: isTrue })}>...</Box>
  ```

### Layout Approach
- **ALWAYS use Flexbox or Grid for layouts** - Never use freeform/absolute positioning when flexbox or grid can achieve the same result
- Prefer Nesto UI layout components: `<Flex />`, `<VStack />`, `<HStack />`, `<Stack />`, `<Grid />`
- **HStack always means row layout** – Use `HStack` for horizontal layouts (`direction="row"`); do not pass `direction="column"` to HStack. Use `VStack` for vertical layouts instead.
- **VStack always means column layout** – Use `VStack` for vertical layouts (`direction="column"`).
- Use flexbox for one-dimensional layouts (rows or columns)
- Use grid for two-dimensional layouts (rows and columns)
- Only use absolute positioning when absolutely necessary (e.g., overlays, tooltips, modals)
- Avoid `position: absolute` for general layout - use flexbox `justify` and `align` props instead
- For centering content, prefer flexbox (`display: flex`, `align-items: center`, `justify-content: center`) over absolute positioning with transforms

### Icons
- **Always use icons from Phosphor Icons library** (`@phosphor-icons/react`)
- Use the **'regular'** style as the default
- Use the **'fill'** style as an available variant when needed
- Import icons from `@phosphor-icons/react` package
- Reference: [Phosphor Icons GitHub](https://github.com/phosphor-icons/homepage)

### Error Handling
- Implement error handling and error logging
- Leave NO todos, placeholders or missing pieces in the code

## Available Components

The following components are available from `fe-shared-master`:

- **Box** - Base component for layout (`cursor/skills/nesto-ui/references/nesto-ui-box.md`)
- **Flex** - Flexbox layout component (`cursor/skills/nesto-ui/references/nesto-ui-flex.md`)
- **Stack / VStack / HStack** - Stack elements with spacing (`cursor/skills/nesto-ui/references/nesto-ui-stack.md`)
- **Button** - Button component with variants (`cursor/skills/nesto-ui/references/nesto-ui-button.md`)
- **ButtonGroup** - Group of buttons (`cursor/skills/nesto-ui/references/nesto-ui-button-group.md`)
- **ButtonIcon** - Icon button (`cursor/skills/nesto-ui/references/nesto-ui-button-icon.md`)
- **Typography** - Typography components (`cursor/skills/nesto-ui/references/nesto-ui-typography.md`)
- **Tabs** - Tab navigation (`cursor/skills/nesto-ui/references/nesto-ui-tabs.md`)
- **Modal** - Modal dialog (`cursor/skills/nesto-ui/references/nesto-ui-modal.md`)
- **Sidebar** - Sidebar component (`cursor/skills/nesto-ui/references/nesto-ui-sidebar.md`)
- **ReactSelect** - Select component (`cursor/skills/nesto-ui/references/nesto-ui-reactselect.md`)

## CSS Design Tokens

All design tokens are available from the `@nestoca/ui` package:
- Import `@nestoca/ui/variables` in your main entry file to load CSS variables
- Reference documentation: `cursor/skills/nesto-ui/references/variables.css` (for reference only)
- **`cursor/skills/nesto-ui/references/nesto-ui-variables.md`** - Variables documentation

Use these variables for:
- Colors: `var(--color-primary-b-500)`, `var(--color-background-muted)`, etc.
- Spacing: `var(--spacing-1)`, `var(--spacing-4)`, etc.
- Typography: `var(--typography-head-5)`, `var(--font-size-2)`, etc.
- Border radius: `var(--border-radius-actions-medium)`, etc.
- Shadows: `var(--shadow-medium)`, etc.

## Specifications Reference

All development must follow the specifications defined in:
- **`cursor/skills/nesto-ui/SKILL.md`** - Main skill definition and preferences
- **`cursor/skills/nesto-ui/references/`** - Detailed component documentation

Refer to these specifications for:
- Component structure and patterns
- Styling guidelines
- Design system tokens
- Component APIs and attributes
- Usage examples

## Project Setup

### Initial Setup

1. **Install dependencies**:
   ```bash
   yarn install
   ```

2. **Set up main entry file** (`src/main.tsx`):
   ```tsx
   import React from 'react'
   import ReactDOM from 'react-dom/client'
   import App from './App.tsx'
   import '@nestoca/ui/style'        // Component styles (required)
   import '@nestoca/ui/variables'   // CSS variables (required)
   import './index.css'              // Your app-specific global styles

   ReactDOM.createRoot(document.getElementById('root')!).render(
     <React.StrictMode>
       <App />
     </React.StrictMode>,
   )
   ```

3. **Build the UI package** (if using local file path dependency):
   ```bash
   cd ../fe-shared-master
   yarn build:design
   ```

**Important**: Always import `@nestoca/ui/style` and `@nestoca/ui/variables` in your main entry file. Do not create local copies of `variables.css` unless you need custom theming.

## Design System Philosophy

### Nesto UI is the Source of Truth

**CRITICAL**: The `@nestoca/ui` design system is the **source of truth** for all component styling, behavior, and design tokens. Figma designs are **reference only** and provide guidance on intent, not exact specifications to replicate.

**Key Principles**:

1. **Use Components As-Is**: 
   - Use `@nestoca/ui` components with their default props and variants
   - Do NOT override component styles (padding, border-radius, font-size, hover states, etc.) to match Figma
   - Components already have correct styling, accessibility, and interactive states built-in

2. **Figma as Reference**:
   - Figma provides guidance on layout, content structure, and component selection
   - Use Figma to understand which components to use and how to arrange them
   - Do NOT treat Figma pixel values as requirements to override component defaults

3. **When Overrides Are Acceptable**:
   - Only override component styles when there is a legitimate design system gap
   - Document why the override is necessary
   - Prefer using component props (`size`, `variant`, etc.) over CSS overrides
   - Never override interactive states (hover, focus, active) - these are handled by the design system

4. **Component Selection Over Style Overrides**:
   - If Figma shows a button, use `<Button />` with appropriate `variant` and `size` props
   - If the default button doesn't match Figma exactly, that's acceptable - the design system takes precedence
   - Trust the design system's built-in styling and interactive states

## Development Workflow

1. **Before starting development**:
   - Review `cursor/skills/nesto-ui/SKILL.md` for technical preferences
   - Check available components in `cursor/skills/nesto-ui/references/`
   - Ensure `@nestoca/ui/variables` is imported in your main entry file
   - Reference `cursor/skills/nesto-ui/references/variables.css` for available CSS variables (reference only)

2. **When implementing components**:
   - **ALWAYS prefer native `fe-shared-master` components over generic alternatives**
     - Use `<Button />` instead of `<Box as="button" />`
     - Use `<Typography />` instead of `<Box as="p" />` or `<Box as="h1" />`
     - Use `<ButtonIcon />` for icon-only buttons instead of `<Box as="button" />` with an icon
     - Only use `<Box as="..." />` when there is no equivalent native component in `fe-shared-master`
   - **ALWAYS use Flexbox or Grid for layouts**
     - Use `<Flex />`, `<VStack />`, `<HStack />`, or `<Stack />` for flexbox layouts
     - Use `<Grid />` for grid layouts
     - Avoid `position: absolute` for general layout - use flexbox `justify` and `align` props instead
     - Only use absolute positioning for overlays, tooltips, modals, or when flexbox/grid cannot achieve the desired layout
   - Use `fe-shared-master` components instead of building custom components
   - Apply styles using CSS modules with CSS variables from `@nestoca/ui/variables`
   - Follow patterns and conventions from `cursor/skills/nesto-ui`
   - Use kebab-case for component file names

3. **When implementing from Figma designs**:
   - **CRITICAL**: Remember that Figma is reference only - Nesto UI components are the source of truth
   - **Component Selection**:
     - Use Figma to identify which `@nestoca/ui` components to use (Button, Typography, etc.)
     - Select appropriate `variant` and `size` props based on Figma's visual intent
     - Do NOT override component styles to match Figma pixel-perfectly
   - **Layout Structure**:
     - Match Figma's auto-layout structure with component hierarchy
     - Use flexbox components (`<Flex />`, `<VStack />`, `<HStack />`) to mirror Figma's layout
     - Preserve nesting levels and grouping from Figma
     - Use `gap` props to match Figma's spacing intent (use design system spacing scale)
     - **CRITICAL**: Always explicitly set `direction="column"` on `VStack` components to ensure column layout
     - **CRITICAL**: Always explicitly set `direction="row"` on `HStack` components to ensure row layout
     - **CRITICAL**: If Figma shows `flex-wrap: wrap`, explicitly set `wrap="wrap"` on Flex/Stack components
   - **Typography**: 
     - Use Typography component with appropriate `font`, `size`, or `weight` props
     - Map Figma text styles to Typography component props, not CSS overrides
     - Only add CSS overrides if Typography component props don't work (document why)
   - **Spacing**:
     - Use design system spacing scale (`gap={1}`, `gap={2}`, etc.) for component gaps
     - Map Figma spacing to `--spacing-*` variables when needed for custom layouts
     - Prefer component `gap` props over custom CSS spacing
   - **Colors**:
     - Use component `variant` props which handle colors automatically
     - Only specify colors directly if component doesn't provide the needed variant
     - Map to `--color-*` variables from `@nestoca/ui/variables`
   - **Verification**:
     - Verify layout structure matches Figma's hierarchy
     - Verify correct components are used with appropriate props
     - Do NOT verify pixel-perfect matching of component styles (design system takes precedence)

3. **Styling approach**:
   - Create a CSS module file with the same name as your component
   - Reference color tokens, spacing, typography from `@nestoca/ui/variables`
   - Use `clsx` for conditional class names
   - Maintain consistency with the design system

## Examples

### ✅ Correct Approach

```tsx
import { Box, Flex, Button, VStack } from '@nestoca/ui'
import { User, Heart } from '@phosphor-icons/react'
import styles from './my-component.module.css'

function MyComponent() {
  return (
    <Box backgroundColor="var(--color-background-muted)">
      <VStack gap={4}>
        <Button variant="primary" size="large">
          Click me
        </Button>
        <Button leftIcon={<User />} variant="secondary">
          With Icon (regular)
        </Button>
        <Button leftIcon={<Heart weight="fill" />} variant="secondary">
          With Icon (fill)
        </Button>
      </VStack>
    </Box>
  )
}

// ✅ Correct: Using flexbox for layout
<Flex align="center" justify="between">
  <Typography>Left content</Typography>
  <Button>Right button</Button>
</Flex>

// ✅ Correct: Using flexbox for centering
<Box className={styles.container}>
  <VStack gap={4} align="center">
    <Typography>Centered content</Typography>
  </VStack>
</Box>
```

### ❌ Incorrect Approach

```tsx
// DO NOT use Tailwind classes
<div className="bg-white p-4 rounded-lg">
  <button className="bg-blue-500 text-white px-4 py-2">
    Click me
  </button>
</div>

// DO NOT use inline styles
<div style={{ backgroundColor: '#fff', padding: '1rem' }}>
  Content
</div>

// DO NOT use Box as a substitute for native components
<Box as="button" onClick={handleClick}>
  Click me
</Box>
// Use Button instead:
<Button onClick={handleClick}>Click me</Button>

// DO NOT use absolute positioning for general layout
<div style={{ position: 'absolute', left: '50%', top: '50%', transform: 'translate(-50%, -50%)' }}>
  Content
</div>
// Use flexbox instead:
<Box className={styles.container}>
  <VStack gap={4} align="center">
    Content
  </VStack>
</Box>
// CSS:
.container {
  display: flex;
  align-items: center;
  justify-content: center;
}

// DO NOT use freeform positioning when flexbox can achieve the same
<div style={{ position: 'relative' }}>
  <div style={{ position: 'absolute', top: '10px', left: '20px' }}>Item</div>
</div>
// Use flexbox instead:
<Flex align="start" gap={2}>
  <Box>Item</Box>
</Flex>

// DO NOT use camelCase for component files
// myComponent.tsx ❌
// my-component.tsx ✅
```

## Anti-patterns and Code Smells

- **Using Box as a substitute for native components**: Avoid `<Box as="button" />` when `<Button />` exists. Native components provide built-in accessibility, focus management, and design system consistency
- **Using absolute positioning for general layout**: Avoid `position: absolute` for layout when flexbox or grid can achieve the same result. Use `<Flex />`, `<VStack />`, `<HStack />`, or `<Grid />` components instead. Only use absolute positioning for overlays, tooltips, modals, or when flexbox/grid cannot achieve the desired layout
- **Freeform positioning**: Avoid manually positioning elements with absolute/fixed positioning when flexbox or grid can handle the layout. Prefer flexbox `justify` and `align` props for spacing and alignment
- **Overriding component styles to match Figma**: Avoid overriding padding, border-radius, font-size, or interactive states (hover, focus, active) to match Figma exactly. The design system components are the source of truth. Use component props instead.
- **Treating Figma as source of truth**: Figma is reference only. The `@nestoca/ui` design system is the authoritative source for component styling and behavior.
- **Direct DOM Manipulation**: Avoid directly manipulating the DOM; let React manage updates
- **Over-reliance on `any` type**: Using `any` in TypeScript defeats the purpose of static typing. Provide explicit types
- **Mutating Props**: Treat props as read-only and avoid modifying them directly
- **Inline Styles**: Keep styles in CSS files for better organization and maintainability. Prefer CSS Modules for component specific styles with the nesto ui lib design token variables

## Migration Notes

The initial implementation used Tailwind CSS. Future development should:
- Migrate existing Tailwind-based components to use `fe-shared-master` and CSS variables
- Remove Tailwind dependencies when no longer needed
- Update all styling to use `@nestoca/ui/variables` tokens
- Convert component files to kebab-case naming
- Replace inline styles with CSS modules
- Migrate existing `react-icons` usage to Phosphor Icons (`@phosphor-icons/react`)
  - Use 'regular' style as default (no weight prop needed)
  - Use 'fill' style by adding `weight="fill"` prop when needed

## Figma Implementation Guidelines

When implementing designs from Figma, follow these guidelines:

**Core Principle**: Nesto UI components are the source of truth. Figma provides guidance on component selection and layout structure, not exact styling specifications.

1. **Component Selection**:
   - Use Figma to identify which `@nestoca/ui` components to use
   - Select appropriate `variant` and `size` props based on visual intent
   - Trust the component's built-in styling - do not override

2. **Layout Structure**:
   - Match Figma's layer hierarchy with component nesting
   - Use flexbox components to mirror Figma's auto-layout
   - Use design system spacing scale for gaps

3. **Typography**:
   - Use Typography component props (`font`, `size`, `weight`)
   - Only add CSS overrides if component props don't work (document why)

4. **Avoid Style Overrides**:
   - Do NOT override padding, border-radius, font-size to match Figma
   - Do NOT override interactive states (hover, focus, active)
   - Use component props and variants instead

See `FIGMA_IMPLEMENTATION_GUIDE.md` for detailed prompt templates and checklists.

## Questions?

If you're unsure about:
- Which component to use from `fe-shared-master` - check `cursor/skills/nesto-ui/references/` for component documentation
- Which CSS variable to use - ensure `@nestoca/ui/variables` is imported, then reference `cursor/skills/nesto-ui/references/variables.css` for available variables
- Component patterns - refer to `cursor/skills/nesto-ui/SKILL.md` and component reference files
- Styling approach - use CSS modules with variables from `@nestoca/ui/variables`
- Figma implementation - see `FIGMA_IMPLEMENTATION_GUIDE.md` for prompt templates and guidelines