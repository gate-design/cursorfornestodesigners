# Figma Implementation Guide

**IMPORTANT**: This guide helps implement designs from Figma, but remember:
- **Nesto UI components are the source of truth** - use them as-is with their default styling
- **Figma is reference only** - it provides guidance on component selection and layout, not exact pixel specifications
- **Do NOT override component styles** (padding, border-radius, font-size, hover states) to match Figma
- **Trust the design system** - components have correct styling, accessibility, and interactive states built-in

This guide provides a structured approach for implementing Figma designs in this project.

## Prompt Template for Figma Implementations

When requesting implementation of a Figma design, use this structured prompt:

```
Implement this design from Figma: [Figma URL]

**Remember**: Nesto UI components are the source of truth. Use components as-is. Figma is reference only.

Requirements:
1. **Component Selection**:
   - Identify which `@nestoca/ui` components to use based on Figma
   - Select appropriate `variant` and `size` props
   - Do NOT override component styles to match Figma exactly

2. **Layout**:
   - Match Figma's auto-layout structure with component hierarchy
   - Use Flexbox or Grid components (Flex, VStack, HStack, Grid)
   - Use design system spacing scale for gaps

3. **Typography**: 
   - Use Typography component with appropriate props (`font`, `size`, `weight`)
   - Map Figma text styles to Typography component props
   - Only add CSS overrides if component props don't work (document why)

4. **Spacing**:
   - Use component `gap` props with design system spacing scale
   - Map to `--spacing-*` variables when needed for custom layouts

5. **Colors**:
   - Use component `variant` props which handle colors automatically
   - Only specify colors directly if component doesn't provide needed variant

6. **Verification**:
   - Verify layout structure matches Figma
   - Verify correct components are used
   - Do NOT verify pixel-perfect style matching (design system takes precedence)
```

## Step-by-Step Implementation Checklist

When implementing from Figma:

### 1. Analyze Figma Design
- [ ] Extract all typography styles (font family, size, weight, line height)
- [ ] Extract all spacing values (gaps, padding, margins)
- [ ] Extract all color values
- [ ] Identify layout structure (auto-layout, frames, groups)
- [ ] Note any special styling (borders, shadows, border-radius)

### 2. Map to Design System
- [ ] Map typography to `--font-size-*` or `--typography-*` variables
- [ ] Map spacing to `--spacing-*` variables
- [ ] Map colors to `--color-*` variables
- [ ] Identify which `@nestoca/ui` components to use

### 3. Implement Component Structure
- [ ] Use flexbox components (Flex, VStack, HStack) to match Figma's auto-layout
- [ ] Preserve Figma's nesting structure in component hierarchy
- [ ] Use native components (Button, Typography) instead of generic Box elements
- [ ] Apply spacing using gap props and CSS variables

### 4. Apply Styling
- [ ] Use CSS modules with design token variables
- [ ] Apply typography styles using Typography component props
- [ ] Apply colors using CSS variables
- [ ] Apply spacing using CSS variables or exact values

### 5. Verify Implementation
- [ ] Check font sizes match Figma (use DevTools computed styles)
- [ ] Check font weights match Figma (use DevTools computed styles)
- [ ] Check line heights match Figma (use DevTools computed styles)
- [ ] Check spacing matches Figma exactly (gaps, padding, margins)
- [ ] Check colors match Figma exactly (background, text, borders)
- [ ] Check layout properties match Figma:
  - [ ] `flex-direction` matches (column/row)
  - [ ] `flex-wrap` matches (wrap/nowrap)
  - [ ] `align-items` matches
  - [ ] `justify-content` matches
  - [ ] `gap` matches exactly
- [ ] Check layout structure matches Figma's hierarchy
- [ ] Verify all buttons are properly styled (pill-shaped if needed)
- [ ] Verify responsive behavior if applicable

## Common Issues and Solutions

### Issue: Font Size Not Matching Figma
**Problem**: Typography component shows wrong font size
**Solution**: 
- Use `size="h5"` with `weight={7}` instead of `font="head-5"` if font prop doesn't work
- Add CSS override: `font-size: var(--font-size-h5) !important;`
- Verify CSS variable is defined: `--font-size-h5: 1.5rem;` (24px)

### Issue: Font Weight Not Matching Figma
**Problem**: Typography component shows wrong font weight (e.g., 400 instead of 700)
**Solution**:
- Always add CSS override in component CSS module: `font-weight: var(--font-weight-7) !important;` (for weight 700)
- Map Figma weight to CSS variable: `--font-weight-1` (100) through `--font-weight-9` (900)
- Verify in DevTools computed styles that font-weight matches Figma exactly

### Issue: Spacing Not Matching Figma
**Problem**: Gaps or padding don't match Figma values
**Solution**:
- Extract exact pixel values from Figma
- Use exact values in CSS if no matching `--spacing-*` variable exists
- Document why exact values were used instead of variables

### Issue: Colors Not Matching Figma
**Problem**: Colors don't match Figma design
**Solution**:
- Extract exact hex/rgb values from Figma
- Find closest matching `--color-*` variable
- If no match, add custom CSS variable or use exact value (document why)

### Issue: Layout Structure Doesn't Match Figma
**Problem**: Component hierarchy doesn't match Figma's layer structure
**Solution**:
- Match Figma's auto-layout groups with VStack/HStack components
- Preserve nesting levels from Figma
- Use flexbox gap props to match Figma's spacing

### Issue: Flex Direction or Wrap Not Matching Figma
**Problem**: VStack/HStack rendering with wrong direction or wrap property
**Solution**:
- **ALWAYS** explicitly set `direction="column"` on `VStack` components
- **ALWAYS** explicitly set `direction="row"` on `HStack` components
- If Figma shows `flex-wrap: wrap`, explicitly set `wrap="wrap"` on Flex/Stack components
- Verify in DevTools that `flex-direction` and `flex-wrap` match Figma exactly
- If component library doesn't apply direction correctly, use `Flex` with explicit `direction` prop instead

## Example: Complete Figma Implementation Prompt

```
Implement this design from Figma: 
@https://www.figma.com/design/RBTP1VHx1D0XRUetkabJXe/PIM---Product-Info-Management?node-id=9548-349714&m=dev

Requirements:
1. **Typography**: 
   - Title "Select Your Workspace" should use `--font-size-h5` (24px/1.5rem) with weight 700
   - Subtitle should use `--typography-body-medium-regular` (14px)
   - Workspace names should use `--typography-body-large-bold` (16px, weight 700)
   - Role badges should use `--font-size-00` (9.6px) with weight 700
   - Verify all font sizes match Figma exactly

2. **Components**:
   - Use `<Typography />` for all text elements
   - Use `<Button />` for Launch and Sign out buttons
   - Use `<Flex />`, `<VStack />`, `<HStack />` for layouts
   - Use Phosphor Icons (Buildings, SignOut)

3. **Layout**:
   - Use flexbox to center main container
   - Use VStack for vertical stacking (header, cards list, sign out button)
   - Use Flex for horizontal layouts (card content, workspace info)
   - Match Figma's auto-layout structure exactly

4. **Spacing**:
   - Main container gap: 32px (use VStack gap={8} or custom CSS)
   - Header gap: 8px (use VStack gap={2})
   - Cards gap: 14px (use custom margin-top)
   - Card padding: 17px (exact value from Figma)
   - Icon container padding: 8px (use --spacing-2)
   - Workspace info gap: 12px (use --spacing-3)

5. **Colors**:
   - Background: `--color-background-muted` (#FAFAFA)
   - Card background: `--color-background-default` (white)
   - Card border: `--color-foreground-disabled` (#E3E3E3)
   - Icon background: `--color-primary-b-200` (#ECF0F7)
   - Icon color: `--color-primary-b-500` (#3D66B0)
   - Button background: `--color-primary-b-200` (#ECF0F7)
   - Button text: `--color-primary-b-500` (#3D66B0)
   - Role badge: `--color-gray-200` (#F5F5F5)

6. **Verification**:
   - Check title is 24px (not 16px)
   - Check all spacing matches Figma exactly
   - Check buttons are pill-shaped (border-radius: 9999px)
   - Check layout structure matches Figma's hierarchy
```

## Quick Reference: Typography Mapping

| Figma Font Size | CSS Variable | Typography Component |
|----------------|--------------|---------------------|
| 24px (1.5rem) | `--font-size-h5` | `size="h5" weight={7}` |
| 16px (1rem) | `--font-size-1` or `--typography-body-large` | `font="body-large"` |
| 14px (0.875rem) | `--font-size-0` or `--typography-body-medium-regular` | `font="body-medium-regular"` |
| 9.6px (0.6rem) | `--font-size-00` | `size="00"` |

## Quick Reference: Spacing Mapping

| Figma Spacing | CSS Variable | Component Prop |
|---------------|--------------|-----------------|
| 8px | `--spacing-2` | `gap={2}` |
| 12px | `--spacing-3` | `gap={3}` |
| 14px | Custom (no variable) | Custom CSS |
| 17px | Custom (no variable) | Custom CSS |
| 32px | `--spacing-6` | `gap={6}` |
