---
name: nesto-ui-modal
description: nesto ui Modal component
---
# Modal

Modal component

### import

`import { Modal } from "fe-shared-master";`

### usage

```tsx
export const Header = () => (
  <Flex align="center" gap={5}>
    <BsClipboardCheck size={24} />
    <Heading weight={7}>Header Title</Heading>
  </Flex>
);

export const Body = () => (
  <form>
    <Flex direction="column" gap={5}>
      <Flex direction="column" gap={5}>
        <Input placeholder="Label" />
        <Flex align="center" gap={5}>
          <Input placeholder="Label" />
          <Input placeholder="Label" />
          <Input placeholder="Label" />
        </Flex>
        <Input placeholder="Label" />
      </Flex>
      <Flex direction="column" gap={5}>
        <Typography weight={7} textColor="var(--color-black)">
          Section Title
        </Typography>
        <Typography size={0} as="p">
          This text is meant to support the section title and sit just
          underneath. The text will wrap the more you write.
        </Typography>
        <Flex align="center" gap={5}>
          <Input placeholder="Label" />
          <Input placeholder="Label" />
        </Flex>
      </Flex>
    </Flex>
  </form>
);

export const Footer = ({ setVisible }) => (
  <Flex justify="end" gap={3}>
    <Button variant="ghost" onClick={() => setVisible(false)}>
      Cancel
    </Button>
    <Button>Submit</Button>
  </Flex>
);

<Box>
    <Button onClick={() => setVisible(true)}>
    Show modal without overlay
    </Button>
    <Modal
        visible={visible}
        overlay={false}
        onClose={() => setVisible(false)}
    >
    <Modal.Header>{<Header />}</Modal.Header>
    <Modal.Body>{<Body />}</Modal.Body>
    <Modal.Footer>{<Footer setVisible={setVisible} />}</Modal.Footer>
    </Modal>
</Box>
```

### attributes
- `visible` - Modal visible state `boolean`, default `false`
- `overlay` - Display an overlay behind the modal `boolean`, default `true`
- `fullScreen` - Display modal in full screen `boolean`, default `false`
- `hideCloseButton` - Hide close button `boolean`, default `false`
- `closeOnEscape` - Close modal on escape key press `boolean`, default `false`
- `closeOnOutsideClick` - Close modal on outside click `boolean`, default `false`
- `closeButtonLabel` - Close button label on mobil `string`, default `"close"`
- `onClose` - Modal onClose handler `() => void`
