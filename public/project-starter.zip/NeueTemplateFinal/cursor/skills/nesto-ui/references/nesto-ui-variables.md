---
name: nesto-ui-variables
description: Nesto UI - css variables tokens for nesto ui design library
---

This varaibles rule is used to get the css tokens from the nesto ui design library.

include the following css varibles from [variables.css](mdc:public/tenant/variables.css)
