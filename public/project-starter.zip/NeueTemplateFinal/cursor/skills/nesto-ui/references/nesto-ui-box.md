---
description: Nesto UI - Box
---

# Box

Box is the most abstract component on top of which all other nesto UI components are built. By default, it renders a div element.

### import

`import { Box } from "fe-shared-master";`

### usage

```tsx
<Box backgroundColor="var(--color-gray-200)">Simple box content</Box>
```

### attributes

- `as` - string or react element, use this attribute to change the default html tag.
- `backgroundColor` - string, use this attribute to change the background color of the box. prefer using nesto css variables.
- `textColor` - string, use this attribute to change the text color of the box. prefer using nesto css variables.
