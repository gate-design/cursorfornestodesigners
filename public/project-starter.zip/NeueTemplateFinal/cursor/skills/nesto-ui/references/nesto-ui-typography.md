---
name: nesto-ui-typography
description: Nesto ui Typography component for displaying text with consistent styling
---
Rule Name: nesto-ui-typography
Description: Nesto UI - Typography component for displaying text with consistent styling

### Overview
The Text primitive is used to display simple strings of text in an interface. It provides a consistent way to style and format text across the application.

### Import
```tsx
import { Typography } from 'fe-shared-master';
```

### Props
The Typography component accepts the following props:

| Prop             | Type                                      | Default   | Description                                  |
|------------------|-------------------------------------------|-----------|----------------------------------------------|
| size             | 0 \| 'h1' \| 'h2' \| 'h3' \| 'h4' \| 'h5' \| 'h6' \| 1 \| 2 \| 3 \| 4 \| 5 \| 6 \| 7 \| '00' \| 'fluid-0' \| 'fluid-1' \| 'fluid-2' \| 'fluid-3' | 1 | The size of the text |
| weight           | 1 \| 2 \| 3 \| 4 \| 5 \| 6 \| 7 \| 8 \| 9 | - | The font weight of the text |
| height           | 0 \| 1 \| 2 \| 3 | - | The line height of the text |
| letterSpacing    | 0 \| 'default' \| 1 \| 2 \| 3 \| 4 \| 5 \| 6 \| 7 \| 'increased' \| 'decreased' | - | The letter spacing of the text |
| font             | 'head-1' \| 'head-2' \| 'head-3' \| 'head-4' \| 'head-5' \| 'head-6' \| 'body-small-regular' \| 'body-small-medium' \| 'body-small-bold' \| 'body-medium-regular' \| 'body-medium' \| 'body-medium-bold' \| 'body-large' \| 'body-large-medium' \| 'body-large-bold' \| 'body-label' \| 'body-caption' \| 'body-placeholder' \| 'subtile-regular' \| 'subtile-bold' | - | Pre-defined set of font properties (recommended approach) |
| backgroundColor  | string | - | The background color of the text |
| textColor        | string | - | The color of the text |
| as               | ElementType | 'span' | The HTML element to render |
| className        | string | - | Additional CSS class names |
| children         | ReactNode | - | The content to be rendered |

### CSS Variables
The Typography component uses the following CSS custom properties:

```css
--typography-font-size: var(--font-size-1);
--typography-weight: var(--font-weight-4);
--typography-spacing: inherit;
--typography-height: inherit;
```

These variables can be customized to adjust the typography styles at the component level.

### Usage Examples

```tsx
// Basic usage with size
<Typography size={1}>Default size text</Typography>

// Using pre-defined font styles (recommended)
<Typography font="head-1">Heading 1</Typography>
<Typography font="body-medium-regular">Body text</Typography>
<Typography font="body-small-bold">Small bold text</Typography>

// Custom styling
<Typography 
  size="h2"
  weight={5}
  height={2}
  letterSpacing="increased"
  textColor="var(--color-primary)"
  backgroundColor="var(--color-background)"
>
  Custom styled text
</Typography>

// Using different HTML elements
<Typography as="label" font="body-label">Form label</Typography>
<Typography as="p" font="body-medium">Paragraph text</Typography>
```

### Best Practices
1. Use the `font` prop as the primary way to style text - it provides consistent, pre-defined combinations
2. Use individual style props (`size`, `weight`, etc.) only when you need custom combinations
3. Use semantic HTML elements with the `as` prop when appropriate
4. Use CSS variables for colors to maintain design system consistency
5. Avoid inline styles; use the component's props instead

### Accessibility
- Use semantic HTML elements with the `as` prop when appropriate
- Maintain proper heading hierarchy when using heading styles
- Ensure sufficient color contrast for readability
- Use appropriate font sizes for readability 
