---
name: nesto-ui-stack
description: nesto ui - Stack VStack Hstack
---

# Stack
Stack is a layout component that makes it easy to stack elements together and apply a space between them.

### import

#### Stack

`import { Stack } from "fe-shared-master";`

#### VStack

`import { VStack } from "fe-shared-master";`

#### HStack

`import { HStack } from "fe-shared-master";`

**HStack always uses `direction="row"`** (horizontal layout). Do not override with `direction="column"`; use VStack for vertical layout.

### attributes

- `gap` - number, use this attribute to change the gap between the elements.
- `direction` - `column` or `row`, use this attribute to change the direction of the stack.
- `align` - `start`, `end`, `center`, `between`, `around`, use this attribute to change the align items of the stack.
- `justify` - `start`, `end`, `center`, `between`, `around`, use this attribute to change the justify content of the stack.
- `wrap` - `nowrap`, `wrap`, `wrap-reverse`, use this attribute to change the flex wrap of the stack.

