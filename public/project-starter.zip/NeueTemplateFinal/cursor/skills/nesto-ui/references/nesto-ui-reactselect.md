---
name: nesto-ui-reactselect
description: nesto ui react select
---

# ReactSelect

Collecting user provided information from a list of options.

## Import

```tsx
import { ReactSelect } from "fe-shared-master";
```

## Props
| Prop | Type | Default | Description |
|------|------|---------|-------------|
| className | string | - | Select classname |
| size | "medium" \| "large" | "medium" | The size of the select component |
| options | { value: string; label: string }[] | - | Options to display in the select |
| required | boolean | false | Whether the select is required to have a value before submitting |
| error | boolean | false | Indicates if the select has an error state |
| isDirty | boolean | false | Indicates if the select value has been modified |
| isMulti | boolean | false | Allow the user to select multiple values |
| isDisabled | boolean | false | Whether the select is disabled |
| isLoading | boolean | false | Whether the select is in a loading state |
| isClearable | boolean | true | Whether the select value can be cleared |
| isSearchable | boolean | true | Whether to enable search functionality |
| menuPlacement | "auto" \| "bottom" \| "top" | "bottom" | The placement of the menu in relation to the control |
| placeholder | string | "Select an option" | Placeholder text when no value is selected |
| menuPosition | "absolute" \| "fixed" | "absolute" | The CSS position property of the menu |
| isOptionDisabled | (option: Option, selectValue: ReadonlyArray<Option>) => boolean | - | Function to determine if an option should be disabled |
| noOptionsMessage | ({ inputValue: string }) => React.ReactNode | () => "No options found" | Function to customize the message shown when no options are available |

## Usage

```tsx
<ReactSelect
    name="shelf"
    isClearable
    isMulti
    isSearchable
    menuPlacement="bottom"
    menuPosition="fixed"
    placeholder="Product shelf"
    className="select"
    options={[
    { label: "Shelf 1", value: "SHELF_1" },
    {
        label: "Shelf 2",
        value: "SHELF_2",
    },
    {
        label: "Shelf 3",
        value: "SHELF_3",
    },
    {
        label: "Shelf 4",
        value: "SHELF_4",
    },
    ]}
    onChange={() => {}}
    aria-required
/>
```
