---
name: nesto-ui-sidebar
description: Nesto UI - Sidebar
---

# Sidebar

import

`import { Sidebar, NavigationLink } from "fe-shared-master";`

css scoped variables

```css

--sidebar-width: 240px;
--sidebar-narrow-width: 48px;
--sidebar-min-height: 100vh;
--sidebar-padding-inline: var(--spacing-4);
--sidebar-position: sticky;
--sidebar-position-top: 0;
--sidebar-background-color: var(--color-gray-000);
--sidebar-text-color: var(--color-brand);
--transition-duration: 0.2s;
--header-padding: var(--spacing-5) var(--spacing-0);
--footer-padding: var(--spacing-5) var(--spacing-0);
```

You can use the <NavigationLink /> component to create a link in the sidebar.

```tsx
<Sidebar>
  <Header>
    header
  </Header>
  <Content>
    navigation links
  </Content>
  <Footer>
    footer element
  </Footer>
</Sidebar>
```

### attributes
`narrow` - boolean, true | false
