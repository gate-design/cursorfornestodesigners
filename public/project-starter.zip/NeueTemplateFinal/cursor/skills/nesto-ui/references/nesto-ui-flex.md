---
name: nesto-ui-flex
description: Nesto UI - Flex
---

# Flex
Use Flex component to position group of sub-elements in one dimension, horizontal or vertical, without being dependent on a custom CSS file for positioning the sub-elements.

### import

`import { Flex } from "fe-shared-master";`

### Css scoped variables

```css
--flex-direction: row;
--flex-justify: normal;
--flex-align-items: normal;
--flex-wrap: nowrap;
--flex-basis: auto;
--flex-grow: 0;
--flex-shrink: 0;
--flex-gap: 0;
```

### usage

```tsx
<Flex>
  <Box>
    Box 1
  </Box>
  <Box>
    Box 2
  </Box>
</Flex>
```

### attributes
- `as` - string or react element, use this attribute to change the default html tag.
- `backgroundColor` - string, use this attribute to change the background color of the box. prefer using nesto css variables.
- `color` - string, use this attribute to change the text color of the box. prefer using nesto css variables.
- `direction` - `column` or `row`, use this attribute to change the direction of the flex container.
- `justify` - `start`, `end`, `center`, `between`, `around`, use this attribute to change the justify content of the flex container.
- `align` - `start`, `end`, `center`, `between`, `around`, use this attribute to change the align items of the flex container.
- `wrap` - `nowrap`, `wrap`, `wrap-reverse`, use this attribute to change the flex wrap of the flex container.
- `gap` - number, use this attribute to change the gap between the flex items.
- `basis` - number, use this attribute to change the basis of the flex item.
- `grow` - number, use this attribute to change the grow of the flex item.
- `shrink` - number, use this attribute to change the shrink of the flex item.

