---
name: nesto-ui-button
description: Nesto UI - Button
---

# Button
Buttons allow users to trigger an action or event with a single click. For example, you can use a button for allowing the functionality of submitting a form, opening a dialog, canceling an action, or performing a delete operation.

### import

`import { Button } from "fe-shared-master";`

### usage

```tsx
<Button
  onClick={clickHandler}
  size="large"
  type="button"
  variant="primary"
>
  Button
</Button>
```

### attributes
- `as` - string or react element, use this attribute to change the default html tag.
- `size` - Size of the button "small", "medium", "large", "xsmall", "xlarge"
- `variant` - Variant of the button "primary", "link", "blank", "secondary", "alternative", "ghost", "critical" default "primary"
`isActive` - Is button loading boolean
`spinner` - Spinner component ReactNode
`spinnerPlacement` - Spinner placement "start", "end" default "end"
`leftIcon` - Add left icon to the button ReactNode
`rightIcon` - Add right icon to the button ReactNode
`type` - Type of the button "button", "submit", "reset" default "button"
`disabled` - Is button disabled boolean
`onClick` - Click handler for the button `((e: MouseEvent<HTMLButtonElement, MouseEvent>) => unknown)`
