---
name: nesto-ui-tabs
description: nesto UI - tab component
---
# Tabs

An accessible tabs component that provides keyboard interactions and ARIA attributes described in the WAI-ARIA Tabs Design Pattern.

## Import

```tsx
import { Tabs, TabList, Tab, TabPanels, TabPanel } from "fe-shared-master";
```

## CSS Variables

```css
--active-color: var(--color-blue-600);
--indicator-thickness: 2px;
```

## Components

### Tabs

#### Props

| Prop | Type | Default | Description |
|------|------|---------|-------------|
| onChange | `(index: number) => void` | - | Called when a tab is selected |
| index | `number` | - | The index of the selected tab |
| defaultIndex | `number` | - | The index of the default tab |
| orientation | `'horizontal' | 'vertical' | 'horizontal'` | The orientation of the tabs |
| backgroundColor | `string` | - | The background color of the tabs |
| textColor | `string` | - | The text color of the tabs |

### TabList

Extends `Flex`

#### Props

| Prop | Type | Default | Description |
|------|------|---------|-------------|
| wrapperClassName | `string` | - | Additional class name for the wrapper element |

### Tab

Extends `Button`

#### Props

| Prop | Type | Default | Description |
|------|------|---------|-------------|
| isActive | `boolean` | `false` | Whether the tab is currently selected |
| isDisabled | `boolean` | `false` | Whether the tab is disabled |

### TabPanels

Extends `Flex` and `HTMLDivElement`

### TabPanel

Extends `Box` and `HTMLDivElement`

## Usage

```tsx
<Tabs onChange={handleChange}>
  <TabList>
    <Tab>
      One
    </Tab>
    <Tab>
      Two
    </Tab>
    <Tab isDisabled>
      Three
    </Tab>
    <Tab>
      Four
    </Tab>
    <Tab>
      Five
    </Tab>
    <Tab>
      My last tab
    </Tab>
  </TabList>
  <TabPanels>
    <TabPanel>
      <p>
        Tab 1 content
      </p>
    </TabPanel>
    <TabPanel>
      <p>
        Tab 2 content
      </p>
    </TabPanel>
    <TabPanel>
      <p>
        Tab 3 content
      </p>
    </TabPanel>
    <TabPanel>
      <p>
        Tab 4 content
      </p>
    </TabPanel>
    <TabPanel>
      <p>
        Tab 5 content
      </p>
    </TabPanel>
    <TabPanel>
      <p>
        Tab 6 content
      </p>
    </TabPanel>
  </TabPanels>
</Tabs>
``` 
