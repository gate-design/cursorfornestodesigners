---
name: nesto-ui-button-group
description: Nesto UI - Button Group
---
# Nesto UI - Button Group

## Description
A Button Group component that allows grouping multiple buttons together with consistent styling and layout options.

## Globs
- "**/*ButtonGroup*.{ts,tsx}"
- "**/*.button-group.{ts,tsx}"

## Always Apply
true

## Import
```typescript
import { ButtonGroup } from "fe-shared-master";
```

## Usage
```typescript
<ButtonGroup>
  <Button>Button</Button>
  <Button>Button</Button>
  <Button>Button</Button>
</ButtonGroup>
```

## Attributes

### className
- Type: `string`
- Description: Button group classname
- Default: `-`

### size
- Type: `"small" | "medium" | "large"`
- Description: Button group size
- Default: `"medium"`

### variant
- Type: `"primary" | "secondary"`
- Description: Button group variant
- Default: `"primary"`

### position
- Type: `"horizontal" | "vertical"`
- Description: Button group position
- Default: `"horizontal"` 
