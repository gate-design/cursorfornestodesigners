---
name: nesto-ui-button-icon
description: Nesto UI - ButtonIcon
---
Nesto UI - Button Icon



A Button Icon component that displays an icon with button functionality, commonly used for actions that can be represented by a single icon.

## Import
```typescript
import { ButtonIcon } from "fe-shared-master";
```

## Usage
```typescript
<ButtonIcon
  icon={<Icon name="close" />}
  onClick={() => console.log('clicked')}
  aria-label="Close"
/>
```

## Attributes

### icon
- Type: `ReactNode`
- Description: Icon element to display in the button
- Default: `-`

### onClick
- Type: `(e: MouseEvent<HTMLButtonElement, MouseEvent>) => unknown`
- Description: Click handler for the button
- Default: `-`

### isActive
- Type: `boolean`
- Description: Is button active
- Default: `false`

### disabled
- Type: `boolean`
- Description: Is button disabled
- Default: `false`

### as
- Type: `string | ComponentClass<any, any> | FunctionComponent<any>`
- Description: Component to render as
- Default: `-`

### type
- Type: `"button" | "submit" | "reset"`
- Description: Type of the button
- Default: `"button"`

### size
- Type: `"small" | "medium" | "large"`
- Description: Size of the button
- Default: `"medium"`

### variant
- Type: `"primary" | "secondary" | "tertiary" | "ghost"`
- Description: Visual variant of the button
- Default: `"primary"`

### className
- Type: `string`
- Description: Additional CSS class name
- Default: `-`

### "aria-label"
- Type: `string`
- Description: Accessible label for the button
- Default: `-` 
